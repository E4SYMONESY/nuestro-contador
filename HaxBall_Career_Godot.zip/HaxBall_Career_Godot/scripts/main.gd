extends Node2D

# HaxBall Career - prototipo offline 2D para Godot 4
# Controles: WASD/flechas para moverse; ESPACIO para patear.
# Todos los jugadores son jugadores de campo: no existe arquero fijo.

const SAVE_PATH := "user://career_save.json"
const FIELD := Rect2(38, 58, 884, 424)
const TEAM_NAMES := ["Del Valle FC", "Atlético Norte", "Deportivo Sur", "Real Central", "Unión Verde", "Estrella Roja", "Puerto Azul", "Fénix FC"]
const FIRST_NAMES := ["Mateo", "Lucas", "Thiago", "Benjamín", "Julián", "Tomás", "Nicolás", "Franco", "Santiago", "Bruno", "Dylan", "Lautaro"]
const LAST_NAMES := ["Fernández", "Romero", "Gómez", "Silva", "Pérez", "Torres", "Díaz", "López", "Martínez", "Acosta", "Molina", "Vega"]

var rng := RandomNumberGenerator.new()
var screen := "menu"
var team_size := 3
var home_team := 0
var away_team := 1
var difficulty := 1
var career_team := 0
var career_season := 1
var career_match := 0
var coins := 500
var wins := 0
var draws := 0
var losses := 0
var goals_for := 0
var goals_against := 0
var mission_progress := {"wins": 0, "goals": 0, "matches": 0}
var mission_claimed := []
var inventory := []
var equipped := {"ball": "classic_ball", "shirt": "classic_kit", "effect": "none"}
var upgrades := {"speed": 0, "control": 0, "power": 0}
var teams: Array = []
var players: Array = []
var match_players: Array = []
var ball_pos := Vector2.ZERO
var ball_vel := Vector2.ZERO
var score := [0, 0]
var match_time := 120.0
var match_running := false
var match_over := false
var user_player := 0
var match_result_saved := false
var current_is_career := false
var kick_cooldown := 0.0
var status_text := "Elegí un modo para comenzar."
var ui_layer: CanvasLayer
var ui_root: VBoxContainer
var title_label: Label
var info_label: Label

func _ready() -> void:
	rng.randomize()
	_load_or_create_data()
	_build_ui()
	queue_redraw()

func _process(delta: float) -> void:
	if screen == "match" and match_running and not match_over:
		_update_match(delta)
		queue_redraw()
	elif screen == "match":
		queue_redraw()

func _draw() -> void:
	if screen == "match":
		_draw_match()
	else:
		_draw_background()

func _draw_background() -> void:
	draw_rect(Rect2(Vector2.ZERO, Vector2(960, 540)), Color("#18251f"))
	draw_rect(Rect2(30, 30, 900, 480), Color("#26352c"), true)
	draw_string(ThemeDB.fallback_font, Vector2(70, 115), "HAXBALL CAREER", HORIZONTAL_ALIGNMENT_LEFT, -1, 34, Color("#f3f3f3"))
	draw_string(ThemeDB.fallback_font, Vector2(72, 150), "Fútbol sala 2D • Offline • Carrera permanente", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("#b9c9bc"))

func _draw_match() -> void:
	draw_rect(Rect2(Vector2.ZERO, Vector2(960, 540)), Color("#302a27"))
	draw_rect(FIELD, Color("#759b68"))
	# Franjas del césped
	for i in range(10):
		if i % 2 == 0:
			draw_rect(Rect2(FIELD.position.x + i * FIELD.size.x / 10.0, FIELD.position.y, FIELD.size.x / 10.0, FIELD.size.y), Color(1, 1, 1, 0.055))
	# Líneas de cancha de futsal
	var line := Color("#e5eadf")
	draw_rect(FIELD, line, false, 3.0)
	draw_line(Vector2(480, FIELD.position.y), Vector2(480, FIELD.end.y), line, 2.0)
	draw_arc(Vector2(480, 270), 55, 0, TAU, 48, line, 2.0)
	draw_circle(Vector2(480, 270), 5, line)
	# Áreas y arcos
	draw_rect(Rect2(38, 190, 95, 160), line, false, 2.0)
	draw_rect(Rect2(827, 190, 95, 160), line, false, 2.0)
	draw_rect(Rect2(18, 225, 20, 90), Color("#e8e8e8"), false, 3.0)
	draw_rect(Rect2(922, 225, 20, 90), Color("#e8e8e8"), false, 3.0)
	# Jugadores
	for p in match_players:
		var c: Color = Color("#e95b50") if p["team"] == 0 else Color("#397bd8")
		draw_circle(p["pos"], 15, Color("#202020"))
		draw_circle(p["pos"], 12, c)
		if p["id"] == user_player:
			draw_arc(p["pos"], 19, 0, TAU, 32, Color("#fff3a6"), 2.0)
		draw_string(ThemeDB.fallback_font, p["pos"] + Vector2(-5, 5), str(p["number"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color.WHITE)
		draw_string(ThemeDB.fallback_font, p["pos"] + Vector2(-23, 27), str(p["name"]).left(11), HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color.WHITE)
	# Pelota
	draw_circle(ball_pos, 8, Color("#f8f8f0"))
	draw_circle(ball_pos, 8, Color("#292929"), false, 1.5)
	# Marcador y tiempo
	draw_rect(Rect2(365, 12, 230, 34), Color("#302a27"))
	draw_string(ThemeDB.fallback_font, Vector2(390, 36), "%d  -  %d" % [score[0], score[1]], HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
	draw_string(ThemeDB.fallback_font, Vector2(520, 35), _format_time(match_time), HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("#f5f5f5"))
	draw_string(ThemeDB.fallback_font, Vector2(42, 520), "WASD/Flechas: mover   ESPACIO: patear", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	if match_over:
		draw_rect(Rect2(280, 190, 400, 130), Color(0, 0, 0, 0.82))
		draw_string(ThemeDB.fallback_font, Vector2(380, 240), "PARTIDO FINALIZADO", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color.WHITE)
		draw_string(ThemeDB.fallback_font, Vector2(410, 278), "%d - %d" % [score[0], score[1]], HORIZONTAL_ALIGNMENT_LEFT, -1, 25, Color("#f3d27a"))

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	ui_root = VBoxContainer.new()
	ui_root.position = Vector2(70, 185)
	ui_root.custom_minimum_size = Vector2(380, 300)
	ui_root.add_theme_constant_override("separation", 9)
	ui_layer.add_child(ui_root)
	_show_menu()

func _clear_ui() -> void:
	for child in ui_root.get_children():
		child.queue_free()

func _add_title(t: String) -> void:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 25)
	l.add_theme_color_override("font_color", Color("#ffffff"))
	ui_root.add_child(l)

func _add_button(t: String, callback: Callable) -> void:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(300, 38)
	b.pressed.connect(callback)
	ui_root.add_child(b)

func _add_label(t: String) -> void:
	var l := Label.new()
	l.text = t
	l.add_theme_color_override("font_color", Color("#e1e8df"))
	ui_root.add_child(l)

func _show_menu() -> void:
	screen = "menu"
	_clear_ui()
	_add_title("HAXBALL CAREER")
	_add_label("FC: %d   |   Temporada: %d" % [coins, career_season])
	_add_button("MODO CARRERA", _show_career)
	_add_button("PARTIDO RAPIDO", _show_quick_setup)
	_add_button("TIENDA FC", _show_store)
	_add_button("MISIONES", _show_missions)
	_add_button("RANKING DE JUGADORES", _show_ranking)
	_add_button("GUARDAR PARTIDA", _save_data)
	_add_label(status_text)

func _show_quick_setup() -> void:
	screen = "quick"
	_clear_ui()
	_add_title("PARTIDO RAPIDO")
	_add_label("Jugadores por equipo: %d vs %d (sin arquero fijo)" % [team_size, team_size])
	_add_button("Cambiar cantidad (1 / 2 / 3)", _cycle_team_size)
	_add_label("Local: %s" % TEAM_NAMES[home_team])
	_add_button("Cambiar equipo local", _cycle_home)
	_add_label("Visitante: %s" % TEAM_NAMES[away_team])
	_add_button("Cambiar equipo visitante", _cycle_away)
	_add_button("Comenzar partido", _start_quick_match)
	_add_button("Volver", _show_menu)

func _cycle_team_size() -> void:
	team_size = (team_size % 3) + 1
	_show_quick_setup()

func _cycle_home() -> void:
	home_team = (home_team + 1) % teams.size()
	if home_team == away_team:
		away_team = (away_team + 1) % teams.size()
	_show_quick_setup()

func _cycle_away() -> void:
	away_team = (away_team + 1) % teams.size()
	if away_team == home_team:
		away_team = (away_team + 1) % teams.size()
	_show_quick_setup()

func _show_career() -> void:
	screen = "career"
	_clear_ui()
	_add_title("MODO CARRERA")
	_add_label("Club: %s" % TEAM_NAMES[career_team])
	_add_label("Temporada %d  |  Jornada %d" % [career_season, career_match + 1])
	_add_label("Formato de carrera: %d vs %d" % [team_size, team_size])
	_add_button("Cambiar formato (1 / 2 / 3 por equipo)", _cycle_career_size)
	_add_label("Récord: %dV - %dE - %dD" % [wins, draws, losses])
	_add_button("Jugar siguiente partido", _start_career_match)
	_add_button("Ver plantel y transferencias", _show_roster)
	_add_button("Finalizar temporada", _finish_season)
	_add_button("Volver", _show_menu)

func _cycle_career_size() -> void:
	team_size = (team_size % 3) + 1
	_show_career()
	_save_data()

func _show_roster() -> void:
	_clear_ui()
	_add_title("PLANTEL Y FICHAJES")
	for p in players:
		if p["team"] == career_team:
			_add_label("%s | %s | OVR %d" % [p["name"], p["position"], p["ovr"]])
	_add_button("Transferir jugador disponible", _transfer_player)
	_add_button("Volver a carrera", _show_career)

func _transfer_player() -> void:
	var target := (career_team + 1) % teams.size()
	var candidate := -1
	for i in range(players.size()):
		if players[i]["team"] != career_team:
			candidate = i
			break
	if candidate >= 0 and coins >= 250:
		coins -= 250
		players[candidate]["team"] = career_team
		status_text = "Fichaste a %s por 250 FC." % players[candidate]["name"]
	else:
		status_text = "No hay jugadores disponibles o faltan FC."
	_show_roster()
	_save_data()

func _finish_season() -> void:
	career_season += 1
	career_match = 0
	for p in players:
		p["age"] = int(p["age"]) + 1
	status_text = "Comenzó la temporada %d." % career_season
	_show_career()
	_save_data()

func _show_store() -> void:
	screen = "store"
	_clear_ui()
	_add_title("FC STORE  |  %d FC" % coins)
	_add_label("Catálogo permanente y destacados rotativos.")
	var items := _store_items()
	for item in items:
		var owned := inventory.has(item["id"])
		_add_button("%s [%s] - %d FC%s" % [item["name"], item["rarity"], item["price"], " (COMPRADO)" if owned else ""], _buy_item.bind(item))
	_add_button("Volver", _show_menu)

func _store_items() -> Array:
	var catalog := [
		{"id":"classic_ball","name":"Pelota clásica","rarity":"Común","price":0,"type":"ball"},
		{"id":"neon_ball","name":"Pelota Neon","rarity":"Raro","price":1200,"type":"ball"},
		{"id":"gold_ball","name":"Pelota dorada","rarity":"Legendario","price":6500,"type":"ball"},
		{"id":"classic_kit","name":"Camiseta clásica","rarity":"Común","price":0,"type":"shirt"},
		{"id":"phantom_kit","name":"Camiseta Phantom","rarity":"Épico","price":3500,"type":"shirt"},
		{"id":"night_arena","name":"Cancha nocturna","rarity":"Épico","price":4200,"type":"stadium"},
		{"id":"speed_boots","name":"Botas ligeras (+1 velocidad)","rarity":"Raro","price":1800,"type":"upgrade"}
	]
	# Selección semanal estable: no depende de generar artículos aleatorios cada apertura.
	var week := int(Time.get_unix_time_from_system() / 604800)
	var featured := [catalog[1 + (week % 2)], catalog[4 + (week % 2)]]
	return [catalog[0], catalog[3], catalog[6]] + featured

func _buy_item(item: Dictionary) -> void:
	if inventory.has(item["id"]):
		status_text = "Ese artículo ya está en tu inventario."
	elif coins < int(item["price"]):
		status_text = "No tenés suficientes FC."
	else:
		coins -= int(item["price"])
		inventory.append(item["id"])
		if item["type"] == "upgrade":
			upgrades["speed"] = mini(5, int(upgrades["speed"]) + 1)
		status_text = "Compraste %s." % item["name"]
	_save_data()
	_show_store()

func _show_missions() -> void:
	screen = "missions"
	_clear_ui()
	_add_title("MISIONES")
	_add_label("Diarias: ganar 2 partidos - 200 FC (%d/2)" % mini(2, int(mission_progress["wins"])))
	_add_label("Diarias: marcar 5 goles - 150 FC (%d/5)" % mini(5, int(mission_progress["goals"])))
	_add_label("Semanales: jugar 10 partidos - 500 FC (%d/10)" % mini(10, int(mission_progress["matches"])))
	_add_button("Reclamar misiones completadas", _claim_missions)
	_add_button("Volver", _show_menu)

func _claim_missions() -> void:
	if int(mission_progress["wins"]) >= 2 and not mission_claimed.has("wins"):
		coins += 200
		mission_claimed.append("wins")
	if int(mission_progress["goals"]) >= 5 and not mission_claimed.has("goals"):
		coins += 150
		mission_claimed.append("goals")
	if int(mission_progress["matches"]) >= 10 and not mission_claimed.has("matches"):
		coins += 500
		mission_claimed.append("matches")
	status_text = "Recompensas reclamadas cuando los objetivos están completos."
	_save_data()
	_show_missions()

func _show_ranking() -> void:
	screen = "ranking"
	_clear_ui()
	_add_title("RANKING GENERAL")
	var sorted_players := players.duplicate(true)
	sorted_players.sort_custom(func(a, b): return int(a["ovr"]) > int(b["ovr"]))
	for i in range(mini(10, sorted_players.size())):
		var p: Dictionary = sorted_players[i]
		_add_label("%d. %s | %s | OVR %d | %d goles" % [i + 1, p["name"], TEAM_NAMES[int(p["team"])], p["ovr"], p["goals"]])
	_add_button("Volver", _show_menu)

func _start_quick_match() -> void:
	_begin_match(false)

func _start_career_match() -> void:
	home_team = career_team
	away_team = (career_team + 1 + career_match) % teams.size()
	_begin_match(true)

func _begin_match(is_career: bool) -> void:
	current_is_career = is_career
	screen = "match"
	match_players.clear()
	score = [0, 0]
	match_time = 120.0
	match_running = true
	match_over = false
	match_result_saved = false
	ball_pos = Vector2(480, 270)
	ball_vel = Vector2.ZERO
	var home_ids := _players_for_team(home_team, team_size)
	var away_ids := _players_for_team(away_team, team_size)
	for i in range(team_size):
		var hp: Dictionary = players[home_ids[i]]
		var ap: Dictionary = players[away_ids[i]]
		match_players.append({"id":i, "team":0, "name":hp["name"], "number":hp["number"], "pos":Vector2(250 + i * 25, 210 + i * 55), "vel":Vector2.ZERO, "speed":150.0 + upgrades["speed"] * 4, "ovr":hp["ovr"]})
		match_players.append({"id":100 + i, "team":1, "name":ap["name"], "number":ap["number"], "pos":Vector2(710 - i * 25, 210 + i * 55), "vel":Vector2.ZERO, "speed":145.0 + difficulty * 8, "ovr":ap["ovr"]})
	user_player = 0
	_clear_ui()
	_add_title("PARTIDO  |  %s vs %s" % [TEAM_NAMES[home_team], TEAM_NAMES[away_team]])
	_add_label("Fútbol sala %dv%d • Sin arquero fijo" % [team_size, team_size])
	_add_button("Abandonar partido", _end_match_early)
	status_text = "Partido en curso."
	queue_redraw()

func _players_for_team(team_id: int, count: int) -> Array:
	var found := []
	for i in range(players.size()):
		if int(players[i]["team"]) == team_id:
			found.append(i)
	while found.size() < count:
		found.append(0)
	return found.slice(0, count)

func _update_match(delta: float) -> void:
	match_time -= delta
	if match_time <= 0:
		match_time = 0
		_finish_match()
		return
	kick_cooldown = maxf(0.0, kick_cooldown - delta)
	var input_dir := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): input_dir.x -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): input_dir.x += 1
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): input_dir.y -= 1
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): input_dir.y += 1
	if input_dir.length_squared() > 1: input_dir = input_dir.normalized()
	var human: Dictionary = match_players[0]
	human["vel"] = input_dir * float(human["speed"])
	if Input.is_key_pressed(KEY_SPACE) and kick_cooldown <= 0.0:
		_try_kick(0)
		kick_cooldown = 0.25
	for i in range(match_players.size()):
		var p: Dictionary = match_players[i]
		if i != 0:
			_ai_move(p, delta)
		p["pos"] += p["vel"] * delta
		p["pos"].x = clampf(p["pos"].x, FIELD.position.x + 15, FIELD.end.x - 15)
		p["pos"].y = clampf(p["pos"].y, FIELD.position.y + 15, FIELD.end.y - 15)
		match_players[i] = p
	# Movimiento y fricción de la pelota
	ball_pos += ball_vel * delta
	ball_vel *= pow(0.985, delta * 60.0)
	if ball_vel.length() < 5: ball_vel = Vector2.ZERO
	# Colisiones jugador-pelota
	for i in range(match_players.size()):
		var p: Dictionary = match_players[i]
		var diff: Vector2 = ball_pos - p["pos"]
		var dist := diff.length()
		if dist < 22 and dist > 0.001:
			var normal := diff / dist
			ball_pos = p["pos"] + normal * 22
			ball_vel += normal * 35
	# Laterales y goles
	if ball_pos.y < FIELD.position.y + 8 or ball_pos.y > FIELD.end.y - 8:
		ball_pos.y = clampf(ball_pos.y, FIELD.position.y + 8, FIELD.end.y - 8)
		ball_vel.y *= -0.75
	if ball_pos.x < 28 and ball_pos.y > 225 and ball_pos.y < 315:
		score[1] += 1
		_reset_ball()
	elif ball_pos.x > 932 and ball_pos.y > 225 and ball_pos.y < 315:
		score[0] += 1
		_reset_ball()
	elif ball_pos.x < FIELD.position.x + 8 or ball_pos.x > FIELD.end.x - 8:
		ball_pos.x = clampf(ball_pos.x, FIELD.position.x + 8, FIELD.end.x - 8)
		ball_vel.x *= -0.75

func _ai_move(p: Dictionary, delta: float) -> void:
	var target := ball_pos
	var is_teammate := int(p["team"]) == 0
	if is_teammate:
		# Los compañeros acompañan la jugada y se abren para ofrecer pase.
		target = ball_pos + Vector2(-55 if ball_pos.x < 480 else 35, (int(p["id"]) % 3 - 1) * 75)
	else:
		# La IA rival presiona la pelota; no hay arquero fijo.
		target = ball_pos + Vector2(18, (int(p["id"]) % 3 - 1) * 22)
	var direction: Vector2 = target - p["pos"]
	if direction.length() > 12:
		p["vel"] = direction.normalized() * float(p["speed"])
	else:
		p["vel"] = Vector2.ZERO
	if p["pos"].distance_to(ball_pos) < 30:
		var toward_goal := Vector2(-1, 0) if int(p["team"]) == 0 else Vector2(1, 0)
		ball_vel += toward_goal * (70.0 + float(p["ovr"]) * 0.5) * delta

func _try_kick(index: int) -> void:
	var p: Dictionary = match_players[index]
	var direction := Vector2(1, 0) if int(p["team"]) == 0 else Vector2(-1, 0)
	if p["pos"].distance_to(ball_pos) < 55:
		ball_vel += direction * (300.0 + upgrades["power"] * 20.0) + p["vel"] * 0.35

func _reset_ball() -> void:
	ball_pos = Vector2(480, 270)
	ball_vel = Vector2.ZERO
	for i in range(match_players.size()):
		var p: Dictionary = match_players[i]
		p["pos"] = Vector2(250 + (i % 2) * 460, 210 + (i % 3) * 55)
		p["vel"] = Vector2.ZERO
		match_players[i] = p

func _finish_match() -> void:
	match_running = false
	match_over = true
	if not match_result_saved:
		_save_match_result()
		match_result_saved = true
	_add_button("Volver al menú", _show_menu)
	_save_data()

func _end_match_early() -> void:
	match_running = false
	match_over = true
	status_text = "Partido abandonado: no se entregaron recompensas."
	_add_button("Volver al menú", _show_menu)

func _save_match_result() -> void:
	var won := score[0] > score[1]
	var tied := score[0] == score[1]
	if won:
		wins += 1
		coins += 150 if current_is_career else 100
		mission_progress["wins"] += 1
	elif tied:
		draws += 1
		coins += 75
	else:
		losses += 1
		coins += 35
	goals_for += score[0]
	goals_against += score[1]
	mission_progress["goals"] += score[0]
	mission_progress["matches"] += 1
	for i in range(match_players.size()):
		var p: Dictionary = match_players[i]
		for j in range(players.size()):
			if players[j]["name"] == p["name"]:
				if int(p["team"]) == 0:
					players[j]["goals"] += 0
				break
	if home_team == career_team:
		career_match += 1
	status_text = "Resultado guardado: %d-%d. FC: %d" % [score[0], score[1], coins]

func _format_time(t: float) -> String:
	var seconds := int(ceil(t))
	return "%02d:%02d" % [seconds / 60, seconds % 60]

func _load_or_create_data() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		var parsed = JSON.parse_string(f.get_as_text())
		if parsed is Dictionary:
			coins = int(parsed.get("coins", coins))
			wins = int(parsed.get("wins", 0))
			draws = int(parsed.get("draws", 0))
			losses = int(parsed.get("losses", 0))
			goals_for = int(parsed.get("goals_for", 0))
			goals_against = int(parsed.get("goals_against", 0))
			career_team = int(parsed.get("career_team", 0))
			career_season = int(parsed.get("career_season", 1))
			career_match = int(parsed.get("career_match", 0))
			team_size = int(parsed.get("team_size", 3))
			inventory = parsed.get("inventory", [])
			equipped = parsed.get("equipped", equipped)
			upgrades = parsed.get("upgrades", upgrades)
			mission_progress = parsed.get("mission_progress", mission_progress)
			mission_claimed = parsed.get("mission_claimed", [])
			teams = parsed.get("teams", [])
			players = parsed.get("players", [])
	if teams.is_empty() or players.is_empty():
		_create_universe()

func _create_universe() -> void:
	teams.clear()
	players.clear()
	for t in range(TEAM_NAMES.size()):
		teams.append({"id":t, "name":TEAM_NAMES[t], "wins":0, "points":0})
		for n in range(6):
			var id := players.size()
			var full_name := FIRST_NAMES[(t * 3 + n) % FIRST_NAMES.size()] + " " + LAST_NAMES[(t + n * 2) % LAST_NAMES.size()]
			var positions := ["Cierre", "Ala", "Pívot", "Ala", "Cierre", "Pívot"]
			players.append({"id":id, "name":full_name, "team":t, "number":n + 1, "position":positions[n], "age":19 + ((t + n) % 12), "ovr":60 + ((t * 7 + n * 5) % 35), "goals":0, "assists":0})
	_save_data()

func _save_data() -> void:
	var data := {
		"coins":coins, "wins":wins, "draws":draws, "losses":losses,
		"goals_for":goals_for, "goals_against":goals_against,
		"career_team":career_team, "career_season":career_season,
		"career_match":career_match, "team_size":team_size,
		"inventory":inventory, "equipped":equipped, "upgrades":upgrades,
		"mission_progress":mission_progress, "mission_claimed":mission_claimed,
		"teams":teams, "players":players
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
	status_text = "Progreso guardado."

