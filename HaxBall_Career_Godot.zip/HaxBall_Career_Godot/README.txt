HAXBALL CAREER - PROTOTIPO GODOT 4

INSTALACION
1. Descargá y descomprimí HaxBall_Career_Godot.zip.
2. Abrí Godot 4.
3. Elegí Importar y seleccioná project.godot dentro de esta carpeta.
4. Abrí el proyecto y presioná F6/F5 (F5 ejecuta el proyecto).

CONTROLES
WASD o flechas: mover al jugador seleccionado.
ESPACIO: patear cuando estás cerca de la pelota.

NOTAS
- Juego 2D offline, vista cenital.
- 1v1, 2v2 y 3v3 seleccionables en Partido rápido.
- No existe arquero fijo.
- Incluye una base funcional inicial de carrera, equipos, jugadores, ranking,
  fichajes simplificados, FC, misiones, tienda e inventario.
- El proyecto es una primera versión jugable para ampliar. Algunas funciones
  avanzadas todavía son simplificadas: reglas completas de futsal, IA táctica
  avanzada, calendario real de rotación, contratos, asistencias y estadísticas
  detalladas necesitan una segunda etapa.
- Guardado en user://career_save.json.
- Renderizador Compatibility para equipos modestos.
